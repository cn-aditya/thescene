<form action="script.php" method="post">
<p>
	<label>Play List Url</label>
	<input type="text" name="url" value="" required>
</p>
<p>
	<label>Play List Name</label>
	<input type="text" name="list_name" value="" required>
</p>
<p>
	<label>Action</label>
	<input type="submit" name="Get All">
</p>
</form>